<?php

// Define base paths relative to the dev folder
define('DEV_ROOT', __DIR__);
define('PROJECT_ROOT', dirname(DEV_ROOT));

// --- AUTO DETECTION LOGIC ---

// 1. Detect Client Path
$clientPaths = ['client', 'frontend', 'react-app', 'src'];
$detectedClient = PROJECT_ROOT . DIRECTORY_SEPARATOR . 'client'; // Default
foreach ($clientPaths as $p) {
    if (file_exists(PROJECT_ROOT . DIRECTORY_SEPARATOR . $p . DIRECTORY_SEPARATOR . 'package.json')) {
        $detectedClient = PROJECT_ROOT . DIRECTORY_SEPARATOR . $p;
        break;
    }
}
define('CLIENT_PATH', $detectedClient);

// 2. Detect Server Path
$serverPaths = ['server', 'backend', 'api', 'php'];
$detectedServer = PROJECT_ROOT . DIRECTORY_SEPARATOR . 'server'; // Default
foreach ($serverPaths as $p) {
    if (file_exists(PROJECT_ROOT . DIRECTORY_SEPARATOR . $p . DIRECTORY_SEPARATOR . 'controllers') || 
        file_exists(PROJECT_ROOT . DIRECTORY_SEPARATOR . $p . DIRECTORY_SEPARATOR . 'models')) {
        $detectedServer = PROJECT_ROOT . DIRECTORY_SEPARATOR . $p;
        break;
    }
}
define('SERVER_PATH', $detectedServer);

// 3. Detect Project Subdirectory (for proxy)
$projectRoot = str_replace('\\', '/', PROJECT_ROOT);
$projectSubdir = '';

// Try to detect via SCRIPT_NAME (Web)
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
if (!empty($scriptName) && strpos($scriptName, '/dev/') !== false) {
    $pathParts = explode('/dev/', $scriptName);
    $projectSubdir = trim($pathParts[0], '/');
} else {
    // Try to detect via Path (CLI/Robust)
    $webRoots = ['/htdocs/', '/www/', '/html/', '/public_html/'];
    $projectSubdir = basename($projectRoot); // Default to folder name
    
    foreach ($webRoots as $root) {
        $parts = explode($root, $projectRoot);
        if (count($parts) > 1) {
            $projectSubdir = trim($parts[1], '/');
            break;
        }
    }
}
define('PROJECT_SUBDIR', $projectSubdir);

// --- PATH DEFINITIONS ---

// Path to the project's target SQLite database
$dbDir = SERVER_PATH . DIRECTORY_SEPARATOR . 'database';
if (!file_exists($dbDir)) @mkdir($dbDir, 0777, true);

$dbFiles = glob($dbDir . DIRECTORY_SEPARATOR . '*.sqlite');
$dbName = !empty($dbFiles) ? basename($dbFiles[0]) : 'project.sqlite';
define('PROJECT_DB_PATH', $dbDir . DIRECTORY_SEPARATOR . $dbName);

// Path to the dev tool's own SQLite database
define('DEV_DB_PATH', DEV_ROOT . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'dev_tool.sqlite');

// Template paths
define('TEMPLATES_PATH', DEV_ROOT . DIRECTORY_SEPARATOR . 'templates');

// Helper to ensure directories exist
function ensureDir($path) {
    if (!file_exists($path)) {
        mkdir($path, 0777, true);
    }
}
